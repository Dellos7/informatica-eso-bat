MKT con IA - Make Chatbot 3.0
================================

NOVEDADES DE LA V3
------------------
- Modo global: el chatbot puede mostrarse automáticamente en todo el sitio.
- Modo manual: sigue disponible el shortcode [make_chatbot].
- Protección contra duplicados: si el shortcode ya está presente y el modo global está activo, solo se renderiza una instancia.
- Visibilidad configurable para escritorio, tablet y móvil.
- Exclusión de páginas concretas en el modo global.
- Las exclusiones globales no bloquean el shortcode: se puede usar como override manual.

SE MANTIENE DE LA V2
--------------------
- Panel de personalización desde Ajustes > Make Chatbot.
- Mensaje de bienvenida editable.
- Título del asistente, placeholder y texto del botón Enviar editables.
- Botón flotante configurable como texto, icono o icono + texto.
- Tres iconos integrados: chat, ayuda y destello.
- Colores configurables para botón flotante, cabecera, mensajes y botón Enviar.
- Ancho y alto iniciales configurables.
- Redimensionado manual por el visitante en escritorio.
- El tamaño elegido por el visitante se recuerda en localStorage.
- Posición inferior izquierda o derecha.
- Interfaz con avatar, indicador de escritura y nueva conversación.
- Enter envía; Shift+Enter inserta un salto de línea.
- Diseño adaptado a móvil.

INSTALACIÓN / ACTUALIZACIÓN
---------------------------
1. WordPress > Plugins > Añadir plugin > Subir plugin.
2. Sube este ZIP.
3. Si WordPress detecta la versión anterior, elige reemplazarla por la nueva.
4. Ve a Ajustes > Make Chatbot.
5. Comprueba el webhook de Make y personaliza el diseño.
6. En Visibilidad, elige:
   - Automático en todo el sitio, o
   - Solo mediante shortcode.
7. Guarda los cambios.

MODO GLOBAL
-----------
Con "Automático en todo el sitio", el plugin se inserta mediante wp_footer.
No es necesario añadir el shortcode a Elementor ni al footer del tema.

Puedes decidir si se muestra en escritorio, tablet y móvil, y excluir páginas
concretas desde Ajustes > Make Chatbot.

SHORTCODE
---------
El shortcode sigue disponible siempre:
[make_chatbot]

Puedes usarlo en Elementor con el widget "Shortcode". En una página excluida
del modo global, el shortcode permite mostrar el chatbot manualmente.

SEGURIDAD
---------
El navegador llama a la REST API de WordPress y WordPress hace la petición
servidor-a-servidor al webhook de Make. La URL del webhook no se expone
en el JavaScript público.

Se mantiene un límite básico de 20 mensajes cada 5 minutos por IP y una
longitud máxima de 2.000 caracteres por mensaje.
