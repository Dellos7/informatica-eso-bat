<?php
/**
 * Plugin Name: MKT con IA - Make Chatbot
 * Description: Chatbot flotante personalizable para WordPress que conecta con un webhook de Make sin exponer su URL en el navegador.
 * Version: 3.0.0
 * Author: MKT con IA
 */

if (!defined('ABSPATH')) {
    exit;
}

define('MKTIA_CHATBOT_OPTION', 'mktia_make_chatbot_webhook');
define('MKTIA_CHATBOT_SETTINGS', 'mktia_make_chatbot_settings');

function mktia_chatbot_defaults() {
    return [
        'assistant_title'      => 'Asistente virtual',
        'welcome_message'     => 'Hola. Puedo ayudarte con dudas sobre nuestros servicios.',
        'placeholder'         => 'Escribe tu pregunta…',
        'send_button_text'    => 'Enviar',
        'floating_mode'       => 'text_icon',
        'floating_text'       => '¿Te ayudamos?',
        'floating_icon'       => 'chat',
        'position'            => 'right',
        'floating_bg'         => '#222222',
        'floating_text_color' => '#ffffff',
        'header_bg'           => '#ffffff',
        'header_text'         => '#171717',
        'panel_bg'            => '#f6f7f9',
        'send_bg'             => '#222222',
        'send_text'           => '#ffffff',
        'user_bg'             => '#222222',
        'user_text'           => '#ffffff',
        'bot_bg'              => '#ffffff',
        'bot_text'            => '#171717',
        'panel_width'         => 380,
        'panel_height'        => 560,
        'allow_resize'        => 1,
        'display_mode'        => 'global',
        'show_desktop'        => 1,
        'show_tablet'         => 1,
        'show_mobile'         => 1,
        'excluded_pages'      => [],
    ];
}

function mktia_chatbot_get_settings() {
    $saved = get_option(MKTIA_CHATBOT_SETTINGS, []);
    if (!is_array($saved)) {
        $saved = [];
    }
    return wp_parse_args($saved, mktia_chatbot_defaults());
}

function mktia_chatbot_sanitize_color($value, $fallback) {
    $color = sanitize_hex_color($value);
    return $color ? $color : $fallback;
}

function mktia_chatbot_sanitize_settings($input) {
    $defaults = mktia_chatbot_defaults();
    $input = is_array($input) ? $input : [];

    $clean = [];
    $clean['assistant_title'] = sanitize_text_field($input['assistant_title'] ?? $defaults['assistant_title']);
    $clean['welcome_message'] = sanitize_textarea_field($input['welcome_message'] ?? $defaults['welcome_message']);
    $clean['placeholder'] = sanitize_text_field($input['placeholder'] ?? $defaults['placeholder']);
    $clean['send_button_text'] = sanitize_text_field($input['send_button_text'] ?? $defaults['send_button_text']);
    $clean['floating_text'] = sanitize_text_field($input['floating_text'] ?? $defaults['floating_text']);

    $modes = ['text', 'icon', 'text_icon'];
    $clean['floating_mode'] = in_array(($input['floating_mode'] ?? ''), $modes, true)
        ? $input['floating_mode']
        : $defaults['floating_mode'];

    $icons = ['chat', 'help', 'spark'];
    $clean['floating_icon'] = in_array(($input['floating_icon'] ?? ''), $icons, true)
        ? $input['floating_icon']
        : $defaults['floating_icon'];

    $positions = ['right', 'left'];
    $clean['position'] = in_array(($input['position'] ?? ''), $positions, true)
        ? $input['position']
        : $defaults['position'];

    foreach ([
        'floating_bg',
        'floating_text_color',
        'header_bg',
        'header_text',
        'panel_bg',
        'send_bg',
        'send_text',
        'user_bg',
        'user_text',
        'bot_bg',
        'bot_text',
    ] as $key) {
        $clean[$key] = mktia_chatbot_sanitize_color($input[$key] ?? '', $defaults[$key]);
    }

    $clean['panel_width'] = min(700, max(300, absint($input['panel_width'] ?? $defaults['panel_width'])));
    $clean['panel_height'] = min(800, max(360, absint($input['panel_height'] ?? $defaults['panel_height'])));
    $clean['allow_resize'] = !empty($input['allow_resize']) ? 1 : 0;

    $display_modes = ['global', 'shortcode'];
    $clean['display_mode'] = in_array(($input['display_mode'] ?? ''), $display_modes, true)
        ? $input['display_mode']
        : $defaults['display_mode'];

    $clean['show_desktop'] = !empty($input['show_desktop']) ? 1 : 0;
    $clean['show_tablet'] = !empty($input['show_tablet']) ? 1 : 0;
    $clean['show_mobile'] = !empty($input['show_mobile']) ? 1 : 0;

    $excluded = isset($input['excluded_pages']) && is_array($input['excluded_pages'])
        ? $input['excluded_pages']
        : [];
    $clean['excluded_pages'] = array_values(array_unique(array_filter(array_map('absint', $excluded))));

    return $clean;
}

function mktia_chatbot_icon_svg($icon = 'chat') {
    $common = 'width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false"';
    if ($icon === 'help') {
        return '<svg '.$common.'><path d="M9.1 9a3 3 0 1 1 5.47 1.7c-.86 1.2-2.07 1.42-2.45 2.55-.11.33-.12.62-.12.75" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="17.4" r="1" fill="currentColor"/><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.8"/></svg>';
    }
    if ($icon === 'spark') {
        return '<svg '.$common.'><path d="M12 3l1.45 4.05L17.5 8.5l-4.05 1.45L12 14l-1.45-4.05L6.5 8.5l4.05-1.45L12 3Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M18.2 13.4l.8 2.1 2.1.8-2.1.8-.8 2.1-.8-2.1-2.1-.8 2.1-.8.8-2.1Z" fill="currentColor"/></svg>';
    }
    return '<svg '.$common.'><path d="M5.5 18.2 3.8 21l3.7-1.25c1.35.8 2.93 1.25 4.6 1.25 4.92 0 8.9-3.58 8.9-8s-3.98-8-8.9-8S3.2 8.58 3.2 13c0 2 .82 3.83 2.3 5.2Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M7.7 12.8h.01M12 12.8h.01M16.3 12.8h.01" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>';
}

add_action('admin_menu', function () {
    add_options_page(
        'Make Chatbot',
        'Make Chatbot',
        'manage_options',
        'mktia-make-chatbot',
        'mktia_chatbot_settings_page'
    );
});

add_action('admin_init', function () {
    register_setting(
        'mktia_chatbot_settings_group',
        MKTIA_CHATBOT_OPTION,
        [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => '',
        ]
    );

    register_setting(
        'mktia_chatbot_settings_group',
        MKTIA_CHATBOT_SETTINGS,
        [
            'type' => 'array',
            'sanitize_callback' => 'mktia_chatbot_sanitize_settings',
            'default' => mktia_chatbot_defaults(),
        ]
    );
});

function mktia_chatbot_color_field($settings, $key, $label) {
    $value = $settings[$key];
    ?>
    <label class="mktia-admin-color">
        <span><?php echo esc_html($label); ?></span>
        <span class="mktia-admin-color__controls">
            <input type="color" data-preview="<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($value); ?>">
            <input
                type="text"
                class="regular-text mktia-color-text"
                name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[<?php echo esc_attr($key); ?>]"
                value="<?php echo esc_attr($value); ?>"
                data-preview="<?php echo esc_attr($key); ?>"
                maxlength="7"
                pattern="#[0-9A-Fa-f]{6}"
            >
        </span>
    </label>
    <?php
}

function mktia_chatbot_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $settings = mktia_chatbot_get_settings();
    ?>
    <div class="wrap mktia-admin">
        <h1>Make Chatbot</h1>
        <p class="description">Configura la conexión con Make y personaliza el aspecto del chatbot sin tocar código.</p>

        <form method="post" action="options.php">
            <?php settings_fields('mktia_chatbot_settings_group'); ?>

            <div class="mktia-admin-grid">
                <div class="mktia-admin-card">
                    <h2>Conexión con Make</h2>
                    <label class="mktia-field">
                        <span class="mktia-field__label">Webhook de Make</span>
                        <input
                            type="url"
                            class="regular-text code"
                            name="<?php echo esc_attr(MKTIA_CHATBOT_OPTION); ?>"
                            value="<?php echo esc_attr(get_option(MKTIA_CHATBOT_OPTION, '')); ?>"
                            placeholder="https://hook.eu1.make.com/..."
                            required
                        >
                        <small>La URL se guarda en WordPress y no se expone en el JavaScript del visitante.</small>
                    </label>

                    <h2>Textos</h2>
                    <label class="mktia-field">
                        <span class="mktia-field__label">Título del chat</span>
                        <input type="text" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[assistant_title]" value="<?php echo esc_attr($settings['assistant_title']); ?>" data-preview="assistant_title">
                    </label>

                    <label class="mktia-field">
                        <span class="mktia-field__label">Mensaje de bienvenida</span>
                        <textarea rows="3" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[welcome_message]" data-preview="welcome_message"><?php echo esc_textarea($settings['welcome_message']); ?></textarea>
                    </label>

                    <label class="mktia-field">
                        <span class="mktia-field__label">Placeholder</span>
                        <input type="text" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[placeholder]" value="<?php echo esc_attr($settings['placeholder']); ?>" data-preview="placeholder">
                    </label>

                    <label class="mktia-field">
                        <span class="mktia-field__label">Texto del botón Enviar</span>
                        <input type="text" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[send_button_text]" value="<?php echo esc_attr($settings['send_button_text']); ?>" data-preview="send_button_text">
                    </label>

                    <h2>Botón flotante</h2>
                    <div class="mktia-field mktia-field--row">
                        <label>
                            <span class="mktia-field__label">Contenido</span>
                            <select name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[floating_mode]" data-preview="floating_mode">
                                <option value="text" <?php selected($settings['floating_mode'], 'text'); ?>>Solo texto</option>
                                <option value="icon" <?php selected($settings['floating_mode'], 'icon'); ?>>Solo icono</option>
                                <option value="text_icon" <?php selected($settings['floating_mode'], 'text_icon'); ?>>Icono + texto</option>
                            </select>
                        </label>
                        <label>
                            <span class="mktia-field__label">Icono</span>
                            <select name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[floating_icon]" data-preview="floating_icon">
                                <option value="chat" <?php selected($settings['floating_icon'], 'chat'); ?>>Chat</option>
                                <option value="help" <?php selected($settings['floating_icon'], 'help'); ?>>Ayuda</option>
                                <option value="spark" <?php selected($settings['floating_icon'], 'spark'); ?>>Destello</option>
                            </select>
                        </label>
                    </div>

                    <label class="mktia-field">
                        <span class="mktia-field__label">Texto del botón flotante</span>
                        <input type="text" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[floating_text]" value="<?php echo esc_attr($settings['floating_text']); ?>" data-preview="floating_text">
                    </label>

                    <label class="mktia-field">
                        <span class="mktia-field__label">Posición</span>
                        <select name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[position]" data-preview="position">
                            <option value="right" <?php selected($settings['position'], 'right'); ?>>Abajo a la derecha</option>
                            <option value="left" <?php selected($settings['position'], 'left'); ?>>Abajo a la izquierda</option>
                        </select>
                    </label>

                    <h2>Tamaño de la ventana</h2>
                    <div class="mktia-field mktia-field--row">
                        <label>
                            <span class="mktia-field__label">Ancho inicial</span>
                            <input type="number" min="300" max="700" step="10" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[panel_width]" value="<?php echo esc_attr($settings['panel_width']); ?>" data-preview="panel_width">
                        </label>
                        <label>
                            <span class="mktia-field__label">Alto inicial</span>
                            <input type="number" min="360" max="800" step="10" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[panel_height]" value="<?php echo esc_attr($settings['panel_height']); ?>" data-preview="panel_height">
                        </label>
                    </div>

                    <label class="mktia-checkbox">
                        <input type="checkbox" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[allow_resize]" value="1" <?php checked($settings['allow_resize'], 1); ?>>
                        <span>Permitir que el visitante redimensione la ventana arrastrando la esquina superior.</span>
                    </label>

                    <h2>Visibilidad</h2>
                    <label class="mktia-field">
                        <span class="mktia-field__label">Modo de visualización</span>
                        <select name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[display_mode]">
                            <option value="global" <?php selected($settings['display_mode'], 'global'); ?>>Automático en todo el sitio</option>
                            <option value="shortcode" <?php selected($settings['display_mode'], 'shortcode'); ?>>Solo mediante shortcode</option>
                        </select>
                        <small>En modo global el plugin inserta el chatbot automáticamente en el frontend. El shortcode seguirá funcionando como alternativa manual.</small>
                    </label>

                    <div class="mktia-field">
                        <span class="mktia-field__label">Mostrar en dispositivos</span>
                        <div class="mktia-device-options">
                            <label class="mktia-checkbox"><input type="checkbox" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[show_desktop]" value="1" <?php checked($settings['show_desktop'], 1); ?>><span>Escritorio</span></label>
                            <label class="mktia-checkbox"><input type="checkbox" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[show_tablet]" value="1" <?php checked($settings['show_tablet'], 1); ?>><span>Tablet</span></label>
                            <label class="mktia-checkbox"><input type="checkbox" name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[show_mobile]" value="1" <?php checked($settings['show_mobile'], 1); ?>><span>Móvil</span></label>
                        </div>
                    </div>

                    <?php
                    $all_pages = get_pages([
                        'sort_column' => 'post_title',
                        'sort_order' => 'ASC',
                        'post_status' => ['publish', 'private'],
                    ]);
                    ?>
                    <label class="mktia-field">
                        <span class="mktia-field__label">Excluir páginas del modo global</span>
                        <select name="<?php echo esc_attr(MKTIA_CHATBOT_SETTINGS); ?>[excluded_pages][]" multiple size="7" class="mktia-page-select">
                            <?php foreach ($all_pages as $page) : ?>
                                <option value="<?php echo esc_attr($page->ID); ?>" <?php selected(in_array((int) $page->ID, array_map('intval', (array) $settings['excluded_pages']), true)); ?>>
                                    <?php echo esc_html($page->post_title ?: ('Página #' . $page->ID)); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small>Usa Ctrl/Cmd + clic para seleccionar varias. Estas exclusiones solo se aplican a la inserción automática; un shortcode colocado manualmente seguirá mostrando el chatbot.</small>
                    </label>
                </div>

                <div class="mktia-admin-card">
                    <h2>Colores</h2>
                    <div class="mktia-color-grid">
                        <?php
                        mktia_chatbot_color_field($settings, 'floating_bg', 'Botón flotante');
                        mktia_chatbot_color_field($settings, 'floating_text_color', 'Texto/icono flotante');
                        mktia_chatbot_color_field($settings, 'header_bg', 'Cabecera');
                        mktia_chatbot_color_field($settings, 'header_text', 'Texto de cabecera');
                        mktia_chatbot_color_field($settings, 'panel_bg', 'Fondo de mensajes');
                        mktia_chatbot_color_field($settings, 'send_bg', 'Botón Enviar');
                        mktia_chatbot_color_field($settings, 'send_text', 'Texto de Enviar');
                        mktia_chatbot_color_field($settings, 'user_bg', 'Mensaje del usuario');
                        mktia_chatbot_color_field($settings, 'user_text', 'Texto del usuario');
                        mktia_chatbot_color_field($settings, 'bot_bg', 'Mensaje del asistente');
                        mktia_chatbot_color_field($settings, 'bot_text', 'Texto del asistente');
                        ?>
                    </div>

                    <h2>Previsualización</h2>
                    <div class="mktia-preview-shell">
                        <div id="mktia-preview" class="mktia-preview" style="
                            --toggle-bg:<?php echo esc_attr($settings['floating_bg']); ?>;
                            --toggle-text:<?php echo esc_attr($settings['floating_text_color']); ?>;
                            --header-bg:<?php echo esc_attr($settings['header_bg']); ?>;
                            --header-text:<?php echo esc_attr($settings['header_text']); ?>;
                            --panel-bg:<?php echo esc_attr($settings['panel_bg']); ?>;
                            --send-bg:<?php echo esc_attr($settings['send_bg']); ?>;
                            --send-text:<?php echo esc_attr($settings['send_text']); ?>;
                            --user-bg:<?php echo esc_attr($settings['user_bg']); ?>;
                            --user-text:<?php echo esc_attr($settings['user_text']); ?>;
                            --bot-bg:<?php echo esc_attr($settings['bot_bg']); ?>;
                            --bot-text:<?php echo esc_attr($settings['bot_text']); ?>;
                        ">
                            <div class="mktia-preview__window">
                                <div class="mktia-preview__header">
                                    <span class="mktia-preview__avatar"><?php echo mktia_chatbot_icon_svg('spark'); ?></span>
                                    <strong data-preview-target="assistant_title"><?php echo esc_html($settings['assistant_title']); ?></strong>
                                    <span class="mktia-preview__close">×</span>
                                </div>
                                <div class="mktia-preview__messages">
                                    <div class="mktia-preview__bubble mktia-preview__bubble--bot" data-preview-target="welcome_message"><?php echo esc_html($settings['welcome_message']); ?></div>
                                    <div class="mktia-preview__bubble mktia-preview__bubble--user">Me gustaría recibir más información.</div>
                                </div>
                                <div class="mktia-preview__form">
                                    <div class="mktia-preview__input" data-preview-target="placeholder"><?php echo esc_html($settings['placeholder']); ?></div>
                                    <button type="button" data-preview-target="send_button_text"><?php echo esc_html($settings['send_button_text']); ?></button>
                                </div>
                            </div>

                            <button type="button" class="mktia-preview__toggle">
                                <span class="mktia-preview__toggle-icon"><?php echo mktia_chatbot_icon_svg($settings['floating_icon']); ?></span>
                                <span class="mktia-preview__toggle-text" data-preview-target="floating_text"><?php echo esc_html($settings['floating_text']); ?></span>
                            </button>
                        </div>
                    </div>

                    <p class="description">La previsualización es aproximada. El tamaño final también se adapta al espacio disponible en móviles.</p>
                    <?php submit_button('Guardar cambios'); ?>
                </div>
            </div>
        </form>

        <div class="mktia-admin-card mktia-admin-card--shortcode">
            <h2>Inserción y shortcode</h2>
            <p><strong>Modo actual:</strong> <?php echo $settings['display_mode'] === 'global' ? 'automático en todo el sitio' : 'solo mediante shortcode'; ?>.</p>
            <p>El shortcode <code>[make_chatbot]</code> sigue disponible siempre. Puedes usarlo en una página, plantilla o widget de shortcode de Elementor. Si ya existe un shortcode en una página y el modo global está activo, el plugin evita renderizar el chatbot dos veces.</p>
        </div>
    </div>

    <style>
        .mktia-admin{max-width:1200px}
        .mktia-admin-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(380px,.9fr);gap:20px;margin-top:20px;align-items:start}
        .mktia-admin-card{background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:22px;box-shadow:0 1px 2px rgba(0,0,0,.03)}
        .mktia-admin-card h2{margin:24px 0 14px;font-size:16px}
        .mktia-admin-card h2:first-child{margin-top:0}
        .mktia-field{display:flex;flex-direction:column;gap:6px;margin-bottom:14px}
        .mktia-field--row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
        .mktia-field--row label{display:flex;flex-direction:column;gap:6px}
        .mktia-field__label{font-weight:600}
        .mktia-field input[type=text],.mktia-field input[type=url],.mktia-field input[type=number],.mktia-field select,.mktia-field textarea{width:100%;max-width:none}
        .mktia-checkbox{display:flex;gap:8px;align-items:flex-start;margin:8px 0 4px}
        .mktia-device-options{display:flex;flex-wrap:wrap;gap:8px 18px}
        .mktia-device-options .mktia-checkbox{margin:0}
        .mktia-page-select{width:100%;max-width:none;min-height:145px}
        .mktia-color-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px 16px}
        .mktia-admin-color{display:flex;flex-direction:column;gap:6px}
        .mktia-admin-color>span:first-child{font-weight:600}
        .mktia-admin-color__controls{display:flex;gap:7px;align-items:center}
        .mktia-admin-color input[type=color]{width:42px;height:34px;padding:1px;border:1px solid #8c8f94;border-radius:5px;background:#fff}
        .mktia-admin-color .mktia-color-text{width:95px}
        .mktia-preview-shell{background:linear-gradient(145deg,#eef1f5,#fafbfc);border:1px solid #e0e3e8;border-radius:16px;padding:18px;min-height:500px;display:flex;align-items:flex-end;justify-content:flex-end;overflow:hidden}
        .mktia-preview{display:flex;flex-direction:column;align-items:flex-end;gap:12px;max-width:100%}
        .mktia-preview__window{width:340px;max-width:100%;height:390px;background:#fff;border:1px solid #e2e5e9;border-radius:18px;box-shadow:0 16px 40px rgba(17,24,39,.14);overflow:hidden;display:flex;flex-direction:column}
        .mktia-preview__header{background:var(--header-bg);color:var(--header-text);display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid rgba(0,0,0,.07)}
        .mktia-preview__avatar{width:30px;height:30px;display:grid;place-items:center;border-radius:50%;background:var(--toggle-bg);color:var(--toggle-text)}
        .mktia-preview__avatar svg{width:16px;height:16px}
        .mktia-preview__header strong{flex:1}
        .mktia-preview__close{font-size:22px;opacity:.65}
        .mktia-preview__messages{flex:1;padding:14px;background:var(--panel-bg);overflow:hidden}
        .mktia-preview__bubble{max-width:82%;padding:10px 12px;border-radius:14px;margin-bottom:10px;box-shadow:0 1px 2px rgba(0,0,0,.05)}
        .mktia-preview__bubble--bot{background:var(--bot-bg);color:var(--bot-text);border-top-left-radius:5px}
        .mktia-preview__bubble--user{background:var(--user-bg);color:var(--user-text);margin-left:auto;border-top-right-radius:5px}
        .mktia-preview__form{display:flex;gap:8px;padding:10px;background:#fff;border-top:1px solid #eceef1}
        .mktia-preview__input{flex:1;border:1px solid #d8dce2;border-radius:10px;padding:10px;color:#858b94;background:#fff}
        .mktia-preview__form button{border:0;border-radius:10px;padding:10px 13px;background:var(--send-bg);color:var(--send-text);font-weight:600}
        .mktia-preview__toggle{display:inline-flex;align-items:center;gap:8px;border:0;border-radius:999px;padding:12px 16px;background:var(--toggle-bg);color:var(--toggle-text);box-shadow:0 8px 22px rgba(0,0,0,.18);font-weight:700}
        .mktia-preview__toggle-icon{display:inline-flex}
        .mktia-admin-card--shortcode{margin-top:20px}
        @media(max-width:900px){.mktia-admin-grid{grid-template-columns:1fr}.mktia-color-grid{grid-template-columns:1fr 1fr}}
        @media(max-width:600px){.mktia-field--row,.mktia-color-grid{grid-template-columns:1fr}}
    </style>

    <script>
    (() => {
        const preview = document.getElementById('mktia-preview');
        if (!preview) return;

        const iconSvgs = {
            chat: <?php echo wp_json_encode(mktia_chatbot_icon_svg('chat')); ?>,
            help: <?php echo wp_json_encode(mktia_chatbot_icon_svg('help')); ?>,
            spark: <?php echo wp_json_encode(mktia_chatbot_icon_svg('spark')); ?>
        };

        const cssVars = {
            floating_bg: '--toggle-bg',
            floating_text_color: '--toggle-text',
            header_bg: '--header-bg',
            header_text: '--header-text',
            panel_bg: '--panel-bg',
            send_bg: '--send-bg',
            send_text: '--send-text',
            user_bg: '--user-bg',
            user_text: '--user-text',
            bot_bg: '--bot-bg',
            bot_text: '--bot-text'
        };

        function updateMode() {
            const mode = document.querySelector('[data-preview="floating_mode"]')?.value || 'text_icon';
            const icon = preview.querySelector('.mktia-preview__toggle-icon');
            const text = preview.querySelector('.mktia-preview__toggle-text');
            icon.style.display = mode === 'text' ? 'none' : 'inline-flex';
            text.style.display = mode === 'icon' ? 'none' : 'inline';
            preview.querySelector('.mktia-preview__toggle').style.padding = mode === 'icon' ? '13px' : '12px 16px';
        }

        document.querySelectorAll('[data-preview]').forEach((field) => {
            const apply = () => {
                const key = field.dataset.preview;
                const value = field.value;

                if (cssVars[key]) {
                    preview.style.setProperty(cssVars[key], value);
                    if (field.type === 'color') {
                        const textInput = document.querySelector('input[type="text"][data-preview="' + key + '"]');
                        if (textInput) textInput.value = value;
                    } else {
                        const colorInput = document.querySelector('input[type="color"][data-preview="' + key + '"]');
                        if (colorInput && /^#[0-9a-f]{6}$/i.test(value)) colorInput.value = value;
                    }
                }

                const target = preview.querySelector('[data-preview-target="' + key + '"]');
                if (target) target.textContent = value;

                if (key === 'floating_icon') {
                    preview.querySelector('.mktia-preview__toggle-icon').innerHTML = iconSvgs[value] || iconSvgs.chat;
                }

                if (key === 'floating_mode') updateMode();

                if (key === 'position') {
                    preview.style.alignItems = value === 'left' ? 'flex-start' : 'flex-end';
                }

                if (key === 'panel_width') {
                    preview.querySelector('.mktia-preview__window').style.width = Math.min(380, Math.max(280, Number(value) * 0.9)) + 'px';
                }

                if (key === 'panel_height') {
                    preview.querySelector('.mktia-preview__window').style.height = Math.min(440, Math.max(320, Number(value) * 0.7)) + 'px';
                }
            };

            field.addEventListener('input', apply);
            field.addEventListener('change', apply);
        });

        updateMode();
    })();
    </script>
    <?php
}

add_action('rest_api_init', function () {
    register_rest_route('mktia-chatbot/v1', '/message', [
        'methods' => 'POST',
        'callback' => 'mktia_chatbot_rest_message',
        'permission_callback' => '__return_true',
    ]);
});

function mktia_chatbot_rest_message(WP_REST_Request $request) {
    $webhook = get_option(MKTIA_CHATBOT_OPTION, '');
    if (!$webhook) {
        return new WP_Error('chatbot_not_configured', 'El chatbot todavía no está configurado.', ['status' => 503]);
    }

    $message = sanitize_textarea_field((string) $request->get_param('message'));
    $thread_id = sanitize_text_field((string) $request->get_param('thread_id'));
    $page_url = esc_url_raw((string) $request->get_param('page_url'));

    if ($message === '') {
        return new WP_Error('empty_message', 'Escribe un mensaje.', ['status' => 400]);
    }

    if (mb_strlen($message) > 2000) {
        return new WP_Error('message_too_long', 'El mensaje es demasiado largo.', ['status' => 400]);
    }

    if ($thread_id === '') {
        $thread_id = wp_generate_uuid4();
    }

    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
    $rate_key = 'mktia_chat_' . md5($ip);
    $count = (int) get_transient($rate_key);

    if ($count >= 20) {
        return new WP_Error('rate_limit', 'Has enviado demasiados mensajes. Inténtalo de nuevo en unos minutos.', ['status' => 429]);
    }

    set_transient($rate_key, $count + 1, 5 * MINUTE_IN_SECONDS);

    $response = wp_remote_post($webhook, [
        'timeout' => 55,
        'headers' => [
            'Content-Type' => 'application/json; charset=utf-8',
        ],
        'body' => wp_json_encode([
            'message' => $message,
            'thread_id' => $thread_id,
            'page_url' => $page_url,
            'lead_name' => '',
            'lead_email' => '',
        ]),
    ]);

    if (is_wp_error($response)) {
        return new WP_Error('make_unavailable', 'No se ha podido contactar con el asistente.', ['status' => 502]);
    }

    $status = wp_remote_retrieve_response_code($response);
    $body = trim((string) wp_remote_retrieve_body($response));

    if ($status < 200 || $status >= 300) {
        return new WP_Error('make_error', 'El asistente no ha podido procesar la consulta.', ['status' => 502]);
    }

    if ($body === '') {
        $body = 'No he podido generar una respuesta. ¿Puedes reformular la pregunta?';
    }

    return rest_ensure_response([
        'reply' => $body,
        'thread_id' => $thread_id,
    ]);
}

function mktia_chatbot_should_render_global() {
    if (is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_trackback()) {
        return false;
    }

    $settings = mktia_chatbot_get_settings();
    if ($settings['display_mode'] !== 'global') {
        return false;
    }

    $excluded = array_map('intval', (array) $settings['excluded_pages']);
    if (!empty($excluded) && is_page($excluded)) {
        return false;
    }

    return true;
}

function mktia_chatbot_render() {
    static $rendered = false;
    if ($rendered) {
        return '';
    }
    $rendered = true;

    $instance = 'mktia-chatbot-' . wp_rand(1000, 999999);
    $endpoint = esc_url_raw(rest_url('mktia-chatbot/v1/message'));
    $s = mktia_chatbot_get_settings();

    $mode = $s['floating_mode'];
    $position = $s['position'];
    $show_icon = in_array($mode, ['icon', 'text_icon'], true);
    $show_text = in_array($mode, ['text', 'text_icon'], true);
    $visibility_classes = [];
    if (empty($s['show_desktop'])) $visibility_classes[] = 'mktia-chatbot--hide-desktop';
    if (empty($s['show_tablet'])) $visibility_classes[] = 'mktia-chatbot--hide-tablet';
    if (empty($s['show_mobile'])) $visibility_classes[] = 'mktia-chatbot--hide-mobile';

    ob_start();
    ?>
    <div
        id="<?php echo esc_attr($instance); ?>"
        class="mktia-chatbot mktia-chatbot--<?php echo esc_attr($position); ?> <?php echo esc_attr(implode(' ', $visibility_classes)); ?>"
        style="
            --mktia-toggle-bg:<?php echo esc_attr($s['floating_bg']); ?>;
            --mktia-toggle-text:<?php echo esc_attr($s['floating_text_color']); ?>;
            --mktia-header-bg:<?php echo esc_attr($s['header_bg']); ?>;
            --mktia-header-text:<?php echo esc_attr($s['header_text']); ?>;
            --mktia-panel-bg:<?php echo esc_attr($s['panel_bg']); ?>;
            --mktia-send-bg:<?php echo esc_attr($s['send_bg']); ?>;
            --mktia-send-text:<?php echo esc_attr($s['send_text']); ?>;
            --mktia-user-bg:<?php echo esc_attr($s['user_bg']); ?>;
            --mktia-user-text:<?php echo esc_attr($s['user_text']); ?>;
            --mktia-bot-bg:<?php echo esc_attr($s['bot_bg']); ?>;
            --mktia-bot-text:<?php echo esc_attr($s['bot_text']); ?>;
            --mktia-width:<?php echo esc_attr($s['panel_width']); ?>px;
            --mktia-height:<?php echo esc_attr($s['panel_height']); ?>px;
        "
        data-resizable="<?php echo esc_attr($s['allow_resize'] ? '1' : '0'); ?>"
        data-position="<?php echo esc_attr($position); ?>"
    >
        <button class="mktia-chatbot__toggle <?php echo $mode === 'icon' ? 'mktia-chatbot__toggle--icon' : ''; ?>" type="button" aria-expanded="false" aria-label="<?php echo esc_attr($s['floating_text']); ?>">
            <?php if ($show_icon) : ?>
                <span class="mktia-chatbot__toggle-icon"><?php echo mktia_chatbot_icon_svg($s['floating_icon']); ?></span>
            <?php endif; ?>
            <?php if ($show_text) : ?>
                <span><?php echo esc_html($s['floating_text']); ?></span>
            <?php endif; ?>
        </button>

        <section class="mktia-chatbot__panel" hidden aria-label="<?php echo esc_attr($s['assistant_title']); ?>">
            <?php if ($s['allow_resize']) : ?>
                <button class="mktia-chatbot__resize" type="button" aria-label="Redimensionar ventana" tabindex="-1"></button>
            <?php endif; ?>

            <div class="mktia-chatbot__header">
                <span class="mktia-chatbot__avatar"><?php echo mktia_chatbot_icon_svg('spark'); ?></span>
                <div class="mktia-chatbot__heading">
                    <strong><?php echo esc_html($s['assistant_title']); ?></strong>
                    <small>En línea</small>
                </div>
                <button class="mktia-chatbot__reset" type="button" aria-label="Nueva conversación" title="Nueva conversación">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 11a8 8 0 1 0-2.35 5.65M20 5v6h-6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                </button>
                <button class="mktia-chatbot__close" type="button" aria-label="Cerrar">×</button>
            </div>

            <div class="mktia-chatbot__messages" aria-live="polite">
                <div class="mktia-chatbot__row mktia-chatbot__row--bot">
                    <span class="mktia-chatbot__mini-avatar"><?php echo mktia_chatbot_icon_svg('spark'); ?></span>
                    <div class="mktia-chatbot__msg mktia-chatbot__msg--bot"><?php echo esc_html($s['welcome_message']); ?></div>
                </div>
            </div>

            <form class="mktia-chatbot__form">
                <label class="screen-reader-text" for="<?php echo esc_attr($instance); ?>-input">Escribe tu mensaje</label>
                <textarea id="<?php echo esc_attr($instance); ?>-input" rows="1" maxlength="2000" autocomplete="off" placeholder="<?php echo esc_attr($s['placeholder']); ?>" required></textarea>
                <button type="submit"><?php echo esc_html($s['send_button_text']); ?></button>
            </form>
        </section>
    </div>

    <style>
    #<?php echo esc_attr($instance); ?>.mktia-chatbot{position:fixed;bottom:20px;z-index:99999;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;line-height:1.4}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--right{right:20px}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--left{left:20px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__toggle{border:0;border-radius:999px;padding:12px 17px;cursor:pointer;display:inline-flex;align-items:center;gap:8px;box-shadow:0 10px 30px rgba(15,23,42,.22);font-weight:700;background:var(--mktia-toggle-bg);color:var(--mktia-toggle-text);transition:transform .18s ease,box-shadow .18s ease}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__toggle:hover{transform:translateY(-2px);box-shadow:0 14px 34px rgba(15,23,42,.28)}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__toggle:focus-visible{outline:3px solid rgba(59,130,246,.35);outline-offset:3px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__toggle--icon{padding:14px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__toggle-icon{display:inline-flex}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__toggle-icon svg{display:block}

    #<?php echo esc_attr($instance); ?> .mktia-chatbot__panel{position:absolute;bottom:64px;width:min(var(--mktia-width),calc(100vw - 32px));height:min(var(--mktia-height),calc(100vh - 110px));min-width:300px;min-height:360px;max-width:min(700px,calc(100vw - 32px));max-height:min(800px,calc(100vh - 110px));background:#fff;color:#171717;border:1px solid rgba(15,23,42,.12);border-radius:20px;box-shadow:0 24px 70px rgba(15,23,42,.24);overflow:hidden}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--right .mktia-chatbot__panel{right:0}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--left .mktia-chatbot__panel{left:0}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__panel:not([hidden]){display:flex;flex-direction:column;animation:mktiaChatIn .18s ease-out}
    @keyframes mktiaChatIn{from{opacity:0;transform:translateY(8px) scale(.985)}to{opacity:1;transform:none}}

    #<?php echo esc_attr($instance); ?> .mktia-chatbot__header{display:flex;align-items:center;gap:10px;padding:13px 14px;background:var(--mktia-header-bg);color:var(--mktia-header-text);border-bottom:1px solid rgba(15,23,42,.08)}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__avatar{width:34px;height:34px;flex:0 0 34px;border-radius:50%;display:grid;place-items:center;background:var(--mktia-toggle-bg);color:var(--mktia-toggle-text)}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__avatar svg{width:17px;height:17px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__heading{display:flex;flex-direction:column;min-width:0;flex:1}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__heading strong{font-size:14px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__heading small{font-size:11px;opacity:.62}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__reset,#<?php echo esc_attr($instance); ?> .mktia-chatbot__close{width:34px;height:34px;border:0;background:transparent;color:inherit;border-radius:10px;display:grid;place-items:center;cursor:pointer;opacity:.72}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__reset:hover,#<?php echo esc_attr($instance); ?> .mktia-chatbot__close:hover{background:rgba(15,23,42,.07);opacity:1}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__close{font-size:25px;line-height:1}

    #<?php echo esc_attr($instance); ?> .mktia-chatbot__messages{flex:1;overflow:auto;padding:16px;background:var(--mktia-panel-bg);scroll-behavior:smooth}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__row{display:flex;align-items:flex-start;gap:8px;margin:0 0 12px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__row--user{justify-content:flex-end}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__mini-avatar{width:26px;height:26px;flex:0 0 26px;border-radius:50%;display:grid;place-items:center;background:var(--mktia-toggle-bg);color:var(--mktia-toggle-text);margin-top:2px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__mini-avatar svg{width:13px;height:13px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__msg{max-width:82%;padding:10px 12px;border-radius:15px;white-space:pre-wrap;overflow-wrap:anywhere;box-shadow:0 1px 2px rgba(15,23,42,.06);font-size:14px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__msg--bot{background:var(--mktia-bot-bg);color:var(--mktia-bot-text);border-top-left-radius:5px;border:1px solid rgba(15,23,42,.06)}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__msg--user{background:var(--mktia-user-bg);color:var(--mktia-user-text);border-top-right-radius:5px}

    #<?php echo esc_attr($instance); ?> .mktia-chatbot__typing{display:inline-flex;gap:4px;align-items:center;min-height:18px}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__typing i{width:6px;height:6px;border-radius:50%;background:currentColor;opacity:.35;animation:mktiaDot 1s infinite ease-in-out}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__typing i:nth-child(2){animation-delay:.14s}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__typing i:nth-child(3){animation-delay:.28s}
    @keyframes mktiaDot{0%,80%,100%{transform:translateY(0);opacity:.3}40%{transform:translateY(-3px);opacity:.75}}

    #<?php echo esc_attr($instance); ?> .mktia-chatbot__form{display:flex;gap:8px;align-items:flex-end;padding:11px;border-top:1px solid rgba(15,23,42,.08);background:#fff}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__form textarea{flex:1;min-width:0;max-height:110px;resize:none;border:1px solid #d5d9df;border-radius:12px;padding:10px 11px;font:inherit;font-size:14px;line-height:1.35;background:#fff;color:#171717;outline:none}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__form textarea:focus{border-color:#9aa3af;box-shadow:0 0 0 3px rgba(59,130,246,.10)}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__form button{border:0;border-radius:11px;padding:10px 14px;min-height:40px;cursor:pointer;font-weight:700;background:var(--mktia-send-bg);color:var(--mktia-send-text)}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__form button:hover{filter:brightness(.96)}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__form button:disabled{opacity:.55;cursor:wait}

    #<?php echo esc_attr($instance); ?> .mktia-chatbot__resize{position:absolute;top:0;z-index:5;width:24px;height:24px;border:0;background:transparent;padding:0;cursor:nwse-resize}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--right .mktia-chatbot__resize{left:0;cursor:nwse-resize}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--left .mktia-chatbot__resize{right:0;cursor:nesw-resize}
    #<?php echo esc_attr($instance); ?> .mktia-chatbot__resize::before{content:"";position:absolute;top:6px;width:10px;height:10px;opacity:.28;border-top:2px solid currentColor}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--right .mktia-chatbot__resize::before{left:6px;border-left:2px solid currentColor}
    #<?php echo esc_attr($instance); ?>.mktia-chatbot--left .mktia-chatbot__resize::before{right:6px;border-right:2px solid currentColor}

    @media(min-width:1025px){
        #<?php echo esc_attr($instance); ?>.mktia-chatbot--hide-desktop{display:none!important}
    }
    @media(min-width:768px) and (max-width:1024px){
        #<?php echo esc_attr($instance); ?>.mktia-chatbot--hide-tablet{display:none!important}
    }
    @media(max-width:767px){
        #<?php echo esc_attr($instance); ?>.mktia-chatbot--hide-mobile{display:none!important}
    }

    @media(max-width:600px){
        #<?php echo esc_attr($instance); ?>.mktia-chatbot--right{right:12px}
        #<?php echo esc_attr($instance); ?>.mktia-chatbot--left{left:12px}
        #<?php echo esc_attr($instance); ?> .mktia-chatbot__panel{width:calc(100vw - 24px)!important;height:min(70vh,620px)!important;min-width:0;max-width:none}
        #<?php echo esc_attr($instance); ?> .mktia-chatbot__resize{display:none}
    }
    </style>

    <script>
    (() => {
        const root = document.getElementById(<?php echo wp_json_encode($instance); ?>);
        if (!root) return;

        const endpoint = <?php echo wp_json_encode($endpoint); ?>;
        const welcomeMessage = <?php echo wp_json_encode($s['welcome_message']); ?>;
        const toggle = root.querySelector('.mktia-chatbot__toggle');
        const close = root.querySelector('.mktia-chatbot__close');
        const reset = root.querySelector('.mktia-chatbot__reset');
        const panel = root.querySelector('.mktia-chatbot__panel');
        const form = root.querySelector('.mktia-chatbot__form');
        const input = form.querySelector('textarea');
        const submit = form.querySelector('button[type="submit"]');
        const messages = root.querySelector('.mktia-chatbot__messages');
        const resizeHandle = root.querySelector('.mktia-chatbot__resize');

        const storageKey = 'mktia_chatbot_thread';
        const sizeKey = 'mktia_chatbot_size_v2';
        let threadId = localStorage.getItem(storageKey);

        function createThreadId() {
            return (window.crypto && crypto.randomUUID)
                ? crypto.randomUUID()
                : 'web-' + Date.now() + '-' + Math.random().toString(36).slice(2);
        }

        if (!threadId) {
            threadId = createThreadId();
            localStorage.setItem(storageKey, threadId);
        }

        function openPanel() {
            panel.hidden = false;
            toggle.setAttribute('aria-expanded', 'true');
            applySavedSize();
            window.setTimeout(() => input.focus(), 50);
        }

        function closePanel() {
            panel.hidden = true;
            toggle.setAttribute('aria-expanded', 'false');
        }

        function botRow(text, typing = false) {
            const row = document.createElement('div');
            row.className = 'mktia-chatbot__row mktia-chatbot__row--bot';

            const avatar = document.createElement('span');
            avatar.className = 'mktia-chatbot__mini-avatar';
            avatar.innerHTML = <?php echo wp_json_encode(mktia_chatbot_icon_svg('spark')); ?>;

            const msg = document.createElement('div');
            msg.className = 'mktia-chatbot__msg mktia-chatbot__msg--bot';

            if (typing) {
                msg.innerHTML = '<span class="mktia-chatbot__typing" aria-label="Escribiendo"><i></i><i></i><i></i></span>';
            } else {
                msg.textContent = text;
            }

            row.appendChild(avatar);
            row.appendChild(msg);
            messages.appendChild(row);
            messages.scrollTop = messages.scrollHeight;
            return {row, msg};
        }

        function userRow(text) {
            const row = document.createElement('div');
            row.className = 'mktia-chatbot__row mktia-chatbot__row--user';
            const msg = document.createElement('div');
            msg.className = 'mktia-chatbot__msg mktia-chatbot__msg--user';
            msg.textContent = text;
            row.appendChild(msg);
            messages.appendChild(row);
            messages.scrollTop = messages.scrollHeight;
        }

        function resetConversation() {
            threadId = createThreadId();
            localStorage.setItem(storageKey, threadId);
            messages.innerHTML = '';
            botRow(welcomeMessage);
            input.value = '';
            input.style.height = 'auto';
            input.focus();
        }

        function autoGrow() {
            input.style.height = 'auto';
            input.style.height = Math.min(input.scrollHeight, 110) + 'px';
        }

        function applySavedSize() {
            if (window.innerWidth <= 600 || root.dataset.resizable !== '1') return;
            try {
                const saved = JSON.parse(localStorage.getItem(sizeKey) || 'null');
                if (!saved || !saved.width || !saved.height) return;
                const maxW = Math.min(700, window.innerWidth - 32);
                const maxH = Math.min(800, window.innerHeight - 110);
                panel.style.width = Math.max(300, Math.min(maxW, saved.width)) + 'px';
                panel.style.height = Math.max(360, Math.min(maxH, saved.height)) + 'px';
            } catch (e) {}
        }

        function enableResize() {
            if (!resizeHandle || root.dataset.resizable !== '1') return;

            resizeHandle.addEventListener('pointerdown', (event) => {
                if (window.innerWidth <= 600) return;
                event.preventDefault();

                const startX = event.clientX;
                const startY = event.clientY;
                const rect = panel.getBoundingClientRect();
                const startW = rect.width;
                const startH = rect.height;
                const isRight = root.dataset.position === 'right';

                resizeHandle.setPointerCapture(event.pointerId);

                const move = (e) => {
                    const maxW = Math.min(700, window.innerWidth - 32);
                    const maxH = Math.min(800, window.innerHeight - 110);
                    const deltaW = isRight ? (startX - e.clientX) : (e.clientX - startX);
                    const deltaH = startY - e.clientY;

                    const width = Math.max(300, Math.min(maxW, startW + deltaW));
                    const height = Math.max(360, Math.min(maxH, startH + deltaH));

                    panel.style.width = width + 'px';
                    panel.style.height = height + 'px';
                };

                const end = () => {
                    resizeHandle.removeEventListener('pointermove', move);
                    resizeHandle.removeEventListener('pointerup', end);
                    resizeHandle.removeEventListener('pointercancel', end);
                    const rectNow = panel.getBoundingClientRect();
                    localStorage.setItem(sizeKey, JSON.stringify({
                        width: Math.round(rectNow.width),
                        height: Math.round(rectNow.height)
                    }));
                };

                resizeHandle.addEventListener('pointermove', move);
                resizeHandle.addEventListener('pointerup', end);
                resizeHandle.addEventListener('pointercancel', end);
            });
        }

        toggle.addEventListener('click', () => panel.hidden ? openPanel() : closePanel());
        close.addEventListener('click', closePanel);
        reset.addEventListener('click', resetConversation);
        input.addEventListener('input', autoGrow);

        input.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                if (typeof form.requestSubmit === 'function') form.requestSubmit();
                else submit.click();
            }
        });

        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const message = input.value.trim();
            if (!message) return;

            userRow(message);
            input.value = '';
            input.style.height = 'auto';
            input.disabled = true;
            submit.disabled = true;

            const pending = botRow('', true);

            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        message,
                        thread_id: threadId,
                        page_url: window.location.href
                    })
                });

                const data = await response.json();
                if (!response.ok) {
                    throw new Error(data && data.message ? data.message : 'Error');
                }

                pending.msg.textContent = data.reply || 'No he podido generar una respuesta.';
                if (data.thread_id) {
                    threadId = data.thread_id;
                    localStorage.setItem(storageKey, threadId);
                }
            } catch (error) {
                pending.msg.textContent = 'Ahora mismo no puedo responder. Inténtalo de nuevo en unos instantes.';
            } finally {
                input.disabled = false;
                submit.disabled = false;
                input.focus();
                messages.scrollTop = messages.scrollHeight;
            }
        });

        enableResize();
        applySavedSize();

        window.addEventListener('resize', () => {
            if (!panel.hidden) applySavedSize();
        });
    })();
    </script>
    <?php
    return ob_get_clean();
}

add_shortcode('make_chatbot', 'mktia_chatbot_render');

add_action('wp_footer', function () {
    if (!mktia_chatbot_should_render_global()) {
        return;
    }

    echo mktia_chatbot_render(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML is escaped inside the renderer.
}, 30);
